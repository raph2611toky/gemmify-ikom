import 'package:flutter/material.dart';

import 'auth/welcome_screen.dart';

class StartupScreen extends StatelessWidget {
  const StartupScreen({super.key});

  @override
  Widget build(BuildContext context) {
    // Aucun écran de chargement artificiel : l'interface apparaît tout de suite.
    return const WelcomeScreen();
  }
}
