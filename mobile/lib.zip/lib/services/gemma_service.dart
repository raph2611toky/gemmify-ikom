import 'dart:async';
import 'dart:convert';
import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter_gemma/flutter_gemma.dart';
import 'package:flutter_gemma_litertlm/flutter_gemma_litertlm.dart';

import '../models/ai_tutor_response.dart';
import '../models/audio_language_mode.dart';
import 'background_model_download_service.dart';
import 'local_learning_database.dart';

class GenerationCancelledException implements Exception {
  const GenerationCancelledException();

  @override
  String toString() => 'GenerationCancelledException';
}

class GemmaService {
  static final GemmaService _instance = GemmaService._internal();

  factory GemmaService() => _instance;

  GemmaService._internal();

  final BackgroundModelDownloadService _downloadService =
      BackgroundModelDownloadService.instance;

  InferenceModel? _model;
  InferenceChat? _chat;
  Future<void>? _engineInitFuture;
  Future<void>? _sessionFuture;

  bool _isReady = false;
  bool _installing = false;
  bool _isGenerating = false;
  bool _supportsImageSession = false;
  bool _supportsAudioSession = false;
  bool _warmedUp = false;

  int _requestSerial = 0;
  int? _activeRequestSerial;
  int _turnsInSession = 0;
  int? _boundConversationId;
  bool _sessionHydrated = false;

  bool get isReady => _isReady;
  bool get isInstalling => _installing;
  bool get isLoading => _sessionFuture != null;
  bool get isGenerating => _isGenerating;
  bool get supportsImages => _chat?.supportsImages ?? false;
  bool get supportsAudio => _chat?.supportAudio ?? false;
  int get currentTokens => _chat?.currentTokens ?? 0;

  static const String modelFileName = 'gemma-4-E2B-it.litertlm';

  static const String modelUrl =
      'https://huggingface.co/'
      'litert-community/gemma-4-E2B-it-litert-lm/'
      'resolve/6e5c4f1e395deb959c494953478fa5cec4b8008f/'
      'gemma-4-E2B-it.litertlm';

  static const int expectedModelBytes = 2588147712;

  Future<void> initEngine() {
    return _engineInitFuture ??= FlutterGemma.initialize(
      inferenceEngines: [LiteRtLmEngine()],
    );
  }

  Future<ModelDownloadSnapshot> startBackgroundDownload() async {
    await initEngine();
    return _downloadService.start(
      url: modelUrl,
      fileName: modelFileName,
      expectedTotalBytes: expectedModelBytes,
    );
  }

  Future<ModelDownloadSnapshot> getDownloadState() async {
    await initEngine();
    return _downloadService.getState();
  }

  Stream<ModelDownloadSnapshot> watchDownload() => _downloadService.watch();

  Future<void> cancelDownload() => _downloadService.cancel();

  Future<bool> isModelAlreadyDownloaded() async {
    await initEngine();
    try {
      return FlutterGemma.hasActiveModel() ||
          await FlutterGemma.isModelInstalled(modelFileName);
    } catch (_) {
      return false;
    }
  }

  Future<void> installDownloadedModel(String filePath) async {
    await initEngine();
    if (_installing) return;
    _installing = true;
    try {
      final file = File(filePath);
      if (!await file.exists()) {
        throw StateError('Le fichier du modèle est introuvable : $filePath');
      }
      final length = await file.length();
      if (length != expectedModelBytes) {
        throw StateError(
          'Fichier incomplet : $length octets sur $expectedModelBytes.',
        );
      }
      await FlutterGemma.installModel(
        modelType: ModelType.gemma4,
        fileType: ModelFileType.litertlm,
      ).fromFile(filePath).install();
    } finally {
      _installing = false;
    }
  }

  Future<void> createSession({
    bool forceRecreate = false,
    bool supportImage = false,
    bool supportAudio = false,
  }) async {
    await initEngine();

    final hasCapabilities =
        (!supportImage || _supportsImageSession) &&
        (!supportAudio || _supportsAudioSession);
    if (!forceRecreate && _isReady && _model != null && hasCapabilities) {
      return;
    }

    final running = _sessionFuture;
    if (running != null) {
      await running;
      if ((!supportImage || _supportsImageSession) &&
          (!supportAudio || _supportsAudioSession)) {
        return;
      }
    }

    final future = _createSessionInternal(
      forceRecreate: forceRecreate,
      supportImage: supportImage,
      supportAudio: supportAudio,
    );
    _sessionFuture = future;
    try {
      await future;
    } finally {
      if (identical(_sessionFuture, future)) _sessionFuture = null;
    }
  }

  Future<void> _createSessionInternal({
    required bool forceRecreate,
    required bool supportImage,
    required bool supportAudio,
  }) async {
    _isReady = false;
    _activeRequestSerial = null;
    _requestSerial++;

    if (_isGenerating) {
      try {
        await _chat?.stopGeneration();
      } catch (_) {}
      _isGenerating = false;
    }

    final capabilityChanged =
        supportImage != _supportsImageSession ||
        supportAudio != _supportsAudioSession;

    await _chat?.close();
    _chat = null;
    _boundConversationId = null;
    _sessionHydrated = false;

    if (_model == null || forceRecreate || capabilityChanged) {
      await _model?.close();
      _model = await FlutterGemma.getActiveModel(
        maxTokens: 2048,
        preferredBackend: PreferredBackend.cpu,
        supportImage: supportImage,
        supportAudio: supportAudio,
        maxNumImages: 1,
      );
      _supportsImageSession = supportImage;
      _supportsAudioSession = supportAudio;
      _warmedUp = false;
    }

    await _createChatOnly();
    _isReady = true;
    debugPrint(
      '🟢 Mpanabe AI prêt : texte=${!supportImage && !supportAudio}, '
      'image=$supportImage, audio=$supportAudio',
    );
  }

  Future<void> _createChatOnly() async {
    final model = _model;
    if (model == null) {
      throw StateError('Le modèle Gemma n’est pas chargé.');
    }

    await _chat?.close();
    _chat = await model.createChat(
      temperature: 0.15,
      topK: 12,
      tokenBuffer: 460,
      maxOutputTokens: 240,
      supportImage: _supportsImageSession,
      supportAudio: _supportsAudioSession,
      supportsFunctionCalls: false,
      modelType: ModelType.gemma4,
      systemInstruction: _systemInstruction,
    );
    _turnsInSession = 0;
    _sessionHydrated = false;
  }

  /// Prépare les kernels de génération avant l'ouverture du chatbot.
  /// Cette attente n'arrive qu'une fois après le chargement du modèle texte.
  Future<void> warmUp() async {
    await createSession();
    if (_warmedUp || _supportsImageSession || _supportsAudioSession) return;
    final chat = _chat;
    if (chat == null) return;

    try {
      await chat.addQueryChunk(
        Message.text(
          text:
              '{"student_message":"Bonjour","task":"Réponds uniquement avec le JSON {\\"response\\":\\"Prêt.\\",\\"choices\\":[],\\"action\\":\\"none\\",\\"memory_summary\\":\\"\\"}."}',
          isUser: true,
        ),
        true,
      );
      await for (final _ in chat.generateChatResponseAsync()) {}
      _warmedUp = true;
    } catch (error) {
      debugPrint('Préparation Gemma ignorée : $error');
    } finally {
      // Nouvelle conversation vide, mais les kernels natifs restent préparés.
      await _createChatOnly();
    }
  }

  static const String _systemInstruction = '''
Tu es Mpanabe AI, tuteur patient pour Madagascar. Réponds dans la langue de l'élève.
Retourne seulement un JSON valide :
{"response":"markdown terminé","choices":[{"id":"a","label":"choix","message":"choix"}],"action":"none|wait_answer|next_step|finish","progress":{"save":false,"skill_id":"","skill_label":"","evidence":"","correct":null,"score":0,"max_score":0,"understanding":0,"xp":0,"lesson_completed":false},"memory_summary":"résumé bref"}
Règles : response ≤ 80 mots, phrases complètes, vrais retours à la ligne, 4 choix maximum. Aucun champ ui/card/function_call. Étape 1 : explication et petite question. Étape 2 : exercice guidé. Étape 3 : jeu ou quiz, une question par tour. N'enregistre une progression qu'après une réponse évaluée.
''';

  static String _audioInstruction(AudioLanguageMode mode) {
    switch (mode) {
      case AudioLanguageMode.malagasy:
        return 'Valio amin’ny teny malagasy. Aza aseho ny transcription.';
      case AudioLanguageMode.mixed:
        return 'Réponds naturellement en malagasy ou en français sans transcription.';
      case AudioLanguageMode.french:
        return 'Réponds en français clair sans afficher la transcription.';
    }
  }

  void _ensureActive(int serial) {
    if (_activeRequestSerial != serial) {
      throw const GenerationCancelledException();
    }
  }

  Future<bool> _ensureChatForConversation(int conversationId) async {
    if (_chat != null &&
        _boundConversationId == null &&
        _turnsInSession == 0) {
      _boundConversationId = conversationId;
      _sessionHydrated = false;
      return true;
    }

    final mustRebuild = _chat == null ||
        _boundConversationId != conversationId ||
        _turnsInSession >= 5 ||
        currentTokens >= 1080;

    if (!mustRebuild) return false;

    await _createChatOnly();
    _boundConversationId = conversationId;
    _sessionHydrated = false;
    debugPrint('♻️ Contexte compact recréé pour la discussion $conversationId');
    return true;
  }

  Future<void> activateConversation(int conversationId) async {
    // La session est changée au prochain envoi pour éviter un travail natif
    // pendant le simple affichage de la liste des discussions.
  }

  Future<AiTutorResponse> sendTutorMessage({
    required int conversationId,
    required String text,
    LessonState activeLesson = const LessonState(),
    bool answerCanBeEvaluated = false,
    Uint8List? imageBytes,
    Uint8List? audioBytes,
    AudioLanguageMode languageMode = AudioLanguageMode.mixed,
  }) async {
    if (_isGenerating) {
      throw StateError('Une réponse est déjà en cours de génération.');
    }
    if (imageBytes != null && audioBytes != null) {
      throw ArgumentError('Envoie une image ou un audio, pas les deux ensemble.');
    }

    final needsImage = imageBytes != null;
    final needsAudio = audioBytes != null;
    await createSession(
      forceRecreate: needsImage && !_supportsImageSession ||
          needsAudio && !_supportsAudioSession,
      supportImage: needsImage || _supportsImageSession,
      supportAudio: needsAudio || _supportsAudioSession,
    );

    _isGenerating = true;
    try {
      final rebuilt = await _ensureChatForConversation(conversationId);
      final response = await _generateOnce(
        conversationId: conversationId,
        text: text,
        activeLesson: activeLesson,
        answerCanBeEvaluated: answerCanBeEvaluated,
        imageBytes: imageBytes,
        audioBytes: audioBytes,
        languageMode: languageMode,
        hydrate: rebuilt || !_sessionHydrated,
      );
      return _validateProgress(response, answerCanBeEvaluated);
    } finally {
      _isGenerating = false;
    }
  }

  Future<AiTutorResponse> _generateOnce({
    required int conversationId,
    required String text,
    required LessonState activeLesson,
    required bool answerCanBeEvaluated,
    required AudioLanguageMode languageMode,
    required bool hydrate,
    Uint8List? imageBytes,
    Uint8List? audioBytes,
  }) async {
    final isMultimodal = imageBytes != null || audioBytes != null;
    final context = hydrate
        ? await LocalLearningDatabase.instance.buildCompactContext(
            conversationId,
            recentMessageCount: isMultimodal ? 1 : 3,
          )
        : const CompactConversationContext(summary: '', recentTurns: []);
    final progress = activeLesson.isActive
        ? await LocalLearningDatabase.instance.buildCompactProgress(
            subject: activeLesson.subject,
            topic: activeLesson.topic,
            limit: 2,
          )
        : const <String, dynamic>{};

    final normalizedText = _clip(text, isMultimodal ? 180 : 360);
    if (normalizedText.isEmpty && imageBytes == null && audioBytes == null) {
      throw ArgumentError('Le message est vide.');
    }

    final envelope = jsonEncode({
      'message': normalizedText,
      if (audioBytes != null) 'audio_rule': _audioInstruction(languageMode),
      if (activeLesson.isActive)
        'lesson': {
          'subject': _clip(activeLesson.subject, 30),
          'topic': _clip(activeLesson.topic, 50),
          'step': activeLesson.step,
          'activity': activeLesson.activity,
        },
      'evaluate_answer': answerCanBeEvaluated,
      if (hydrate && context.summary.isNotEmpty) 'summary': context.summary,
      if (hydrate && context.recentTurns.isNotEmpty)
        'recent_same_chat': context.recentTurns,
      if (progress.isNotEmpty) 'progress': progress,
      'task': _taskFor(activeLesson, answerCanBeEvaluated),
    });

    final serial = ++_requestSerial;
    _activeRequestSerial = serial;
    try {
      final response = await _runGeneration(
        serial: serial,
        envelope: envelope,
        activeLesson: activeLesson,
        imageBytes: imageBytes,
        audioBytes: audioBytes,
      );
      _sessionHydrated = true;
      return response;
    } finally {
      if (_activeRequestSerial == serial) _activeRequestSerial = null;
    }
  }

  Future<AiTutorResponse> _runGeneration({
    required int serial,
    required String envelope,
    required LessonState activeLesson,
    Uint8List? imageBytes,
    Uint8List? audioBytes,
  }) async {
    final chat = _chat;
    if (chat == null) throw StateError('La session Gemma est indisponible.');

    final Message message;
    if (audioBytes != null && audioBytes.isNotEmpty) {
      message = Message.withAudio(
        text: envelope,
        audioBytes: audioBytes,
        isUser: true,
      );
    } else if (imageBytes != null && imageBytes.isNotEmpty) {
      message = Message.withImages(
        text: envelope,
        imageBytes: [imageBytes],
        isUser: true,
      );
    } else {
      message = Message.text(text: envelope, isUser: true);
    }

    await chat.addQueryChunk(message, true);
    _ensureActive(serial);

    final buffer = StringBuffer();
    await for (final item in chat.generateChatResponseAsync()) {
      _ensureActive(serial);
      if (item is TextResponse) buffer.write(item.token);
    }
    _ensureActive(serial);
    _turnsInSession++;

    return AiTutorResponse.parse(buffer.toString()).normalized(
      fallbackLesson: activeLesson,
      lessonMode: activeLesson.isActive,
    );
  }

  AiTutorResponse _validateProgress(
    AiTutorResponse response,
    bool answerCanBeEvaluated,
  ) {
    if (!response.progress.save || answerCanBeEvaluated) return response;
    return response.copyWith(progress: const ProgressUpdate());
  }

  Future<void> stopGeneration() async {
    _activeRequestSerial = null;
    _requestSerial++;
    if (!_isGenerating) return;
    try {
      await _chat?.stopGeneration();
    } catch (error) {
      debugPrint('Arrêt de génération : $error');
    } finally {
      _isGenerating = false;
    }
  }

  Future<void> resetConversationSession({int? conversationId}) async {
    if (_isGenerating) await stopGeneration();
    if (_model == null) {
      await createSession();
      return;
    }
    await _createChatOnly();
    _boundConversationId = conversationId;
    _sessionHydrated = false;
    _isReady = true;
  }

  Future<void> dispose() async {
    if (_isGenerating) await stopGeneration();
    await _chat?.close();
    _chat = null;
    await _model?.close();
    _model = null;
    _boundConversationId = null;
    _isReady = false;
    _supportsImageSession = false;
    _supportsAudioSession = false;
    _warmedUp = false;
  }
}

String _taskFor(LessonState lesson, bool answerExpected) {
  if (!lesson.isActive) {
    return 'Réponds brièvement et utilement. Ajoute des choix seulement si nécessaire.';
  }
  if (lesson.step <= 1) {
    return answerExpected
        ? 'Corrige la réponse. Si elle est bonne, passe à un exercice; sinon réexplique plus simplement.'
        : 'Explique pédagogiquement avec un exemple puis pose une petite question à choix.';
  }
  if (lesson.step == 2) {
    return answerExpected
        ? 'Corrige l’exercice. Bonne réponse: annonce les jeux. Erreur: explique puis propose plus simple.'
        : 'Propose un seul exercice guidé avec 3 ou 4 choix.';
  }
  return answerExpected
      ? 'Corrige ce défi et continue le jeu une question à la fois.'
      : 'Lance le jeu choisi avec une règle courte et une question à choix.';
}

String _clip(String value, int maxLength) {
  final clean = value.replaceAll(RegExp(r'\s+'), ' ').trim();
  if (clean.length <= maxLength) return clean;
  return '${clean.substring(0, maxLength - 1).trimRight()}…';
}
