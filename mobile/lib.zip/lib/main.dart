import 'package:flutter/material.dart';

import 'screens/startup_screen.dart';
import 'services/local_learning_database.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Supprime une seule fois l'ancienne base locale puis utilise uniquement
  // la mémoire vive. Le moteur IA n'est plus chargé avant l'affichage des
  // pages d'accueil et d'authentification.
  await LocalLearningDatabase.instance.initialize();

  runApp(const GemmafyApp());
}

class GemmafyApp extends StatelessWidget {
  const GemmafyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Gemma Edu',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.theme,
      builder: (context, child) {
        final media = MediaQuery.of(context);
        return MediaQuery(
          data: media.copyWith(
            textScaler: const TextScaler.linear(1.0),
          ),
          child: child ?? const SizedBox.shrink(),
        );
      },
      home: const StartupScreen(),
    );
  }
}
