import 'dart:convert';

class TutorChoice {
  final String id;
  final String label;
  final String message;

  const TutorChoice({
    required this.id,
    required this.label,
    required this.message,
  });

  factory TutorChoice.fromDynamic(dynamic value, int index) {
    if (value is String) {
      final text = _cleanInline(value);
      return TutorChoice(id: 'choice_$index', label: text, message: text);
    }
    if (value is Map) {
      final map = Map<String, dynamic>.from(value);
      final label = _cleanInline(
        map['label'] ?? map['text'] ?? map['title'] ?? map['value'],
      );
      final message = _cleanInline(
        map['message'] ?? map['prompt'] ?? map['value'] ?? label,
      );
      return TutorChoice(
        id: _cleanInline(map['id']).isEmpty
            ? 'choice_$index'
            : _cleanInline(map['id']),
        label: label.isEmpty ? message : label,
        message: message.isEmpty ? label : message,
      );
    }
    final text = _cleanInline(value);
    return TutorChoice(id: 'choice_$index', label: text, message: text);
  }

  Map<String, dynamic> toJson() => {
        'id': id,
        'label': label,
        'message': message,
      };
}

class LessonState {
  final String courseId;
  final String subject;
  final String topic;
  final String activity;
  final String stage;
  final int step;
  final int totalSteps;
  final bool awaitingAnswer;
  final bool completed;

  const LessonState({
    this.courseId = '',
    this.subject = '',
    this.topic = '',
    this.activity = '',
    this.stage = '',
    this.step = 0,
    this.totalSteps = 3,
    this.awaitingAnswer = false,
    this.completed = false,
  });

  bool get isActive => courseId.trim().isNotEmpty && !completed;

  factory LessonState.fromDynamic(dynamic value) {
    final map = value is Map
        ? Map<String, dynamic>.from(value)
        : <String, dynamic>{};
    final status = _cleanInline(map['status']).toLowerCase();
    return LessonState(
      courseId: _cleanInline(
        map['course_id'] ?? map['courseId'] ?? map['id'],
      ),
      subject: _cleanInline(map['subject'] ?? map['matiere']),
      topic: _cleanInline(map['topic'] ?? map['title'] ?? map['lesson']),
      activity: _cleanInline(map['activity'] ?? map['mode'] ?? map['type']),
      stage: _cleanInline(map['stage'] ?? map['step_name'] ?? map['phase']),
      step: _asInt(map['step'] ?? map['step_index']).clamp(0, 3).toInt(),
      totalSteps: _asInt(
        map['total_steps'] ?? map['totalSteps'],
        fallback: 3,
      ).clamp(1, 3).toInt(),
      awaitingAnswer: _asBool(
        map['awaiting_answer'] ?? map['awaitingAnswer'],
      ),
      completed: _asBool(map['completed']) || status == 'completed',
    );
  }

  LessonState copyWith({
    String? courseId,
    String? subject,
    String? topic,
    String? activity,
    String? stage,
    int? step,
    int? totalSteps,
    bool? awaitingAnswer,
    bool? completed,
  }) {
    return LessonState(
      courseId: courseId ?? this.courseId,
      subject: subject ?? this.subject,
      topic: topic ?? this.topic,
      activity: activity ?? this.activity,
      stage: stage ?? this.stage,
      step: step ?? this.step,
      totalSteps: totalSteps ?? this.totalSteps,
      awaitingAnswer: awaitingAnswer ?? this.awaitingAnswer,
      completed: completed ?? this.completed,
    );
  }

  Map<String, dynamic> toJson() => {
        'course_id': courseId,
        'subject': subject,
        'topic': topic,
        'activity': activity,
        'stage': stage,
        'step': step,
        'total_steps': totalSteps,
        'awaiting_answer': awaitingAnswer,
        'completed': completed,
      };
}

class ProgressUpdate {
  final bool save;
  final String skillId;
  final String skillLabel;
  final String evidence;
  final bool? correct;
  final int score;
  final int maxScore;
  final int understanding;
  final int xp;
  final bool lessonCompleted;

  const ProgressUpdate({
    this.save = false,
    this.skillId = '',
    this.skillLabel = '',
    this.evidence = '',
    this.correct,
    this.score = 0,
    this.maxScore = 0,
    this.understanding = 0,
    this.xp = 0,
    this.lessonCompleted = false,
  });

  bool get isValid {
    if (!save) return false;
    final hasEvidence =
        skillLabel.trim().isNotEmpty && evidence.trim().isNotEmpty;
    final hasScore = maxScore > 0 && score >= 0 && score <= maxScore;
    return hasEvidence || hasScore;
  }

  factory ProgressUpdate.fromDynamic(dynamic value) {
    final map = value is Map
        ? Map<String, dynamic>.from(value)
        : <String, dynamic>{};

    final rawSkills = map['skills'];
    Map<String, dynamic> firstSkill = const {};
    if (rawSkills is List && rawSkills.isNotEmpty && rawSkills.first is Map) {
      firstSkill = Map<String, dynamic>.from(rawSkills.first as Map);
    }

    return ProgressUpdate(
      save: _asBool(map['save'] ?? map['should_save'] ?? map['record']),
      skillId: _cleanInline(
        map['skill_id'] ?? firstSkill['id'] ?? firstSkill['skill_id'],
      ),
      skillLabel: _cleanInline(
        map['skill_label'] ?? firstSkill['label'] ?? firstSkill['name'],
      ),
      evidence: normalizeTutorMarkdown(
        map['evidence'] ?? firstSkill['evidence'] ?? firstSkill['feedback'],
      ),
      correct: _asNullableBool(map['correct'] ?? firstSkill['correct']),
      score: _asInt(map['score']),
      maxScore: _asInt(map['max_score'] ?? map['maxScore']),
      understanding: _asInt(
        map['understanding'] ?? firstSkill['mastery'],
      ).clamp(0, 100).toInt(),
      xp: _asInt(map['xp']).clamp(0, 250).toInt(),
      lessonCompleted: _asBool(
        map['lesson_completed'] ?? map['lessonCompleted'],
      ),
    );
  }

  ProgressUpdate copyWith({
    bool? save,
    String? skillId,
    String? skillLabel,
    String? evidence,
    bool? correct,
    bool clearCorrect = false,
    int? score,
    int? maxScore,
    int? understanding,
    int? xp,
    bool? lessonCompleted,
  }) {
    return ProgressUpdate(
      save: save ?? this.save,
      skillId: skillId ?? this.skillId,
      skillLabel: skillLabel ?? this.skillLabel,
      evidence: evidence ?? this.evidence,
      correct: clearCorrect ? null : (correct ?? this.correct),
      score: score ?? this.score,
      maxScore: maxScore ?? this.maxScore,
      understanding: understanding ?? this.understanding,
      xp: xp ?? this.xp,
      lessonCompleted: lessonCompleted ?? this.lessonCompleted,
    );
  }

  Map<String, dynamic> toJson() => {
        'save': save,
        'skill_id': skillId,
        'skill_label': skillLabel,
        'evidence': evidence,
        'correct': correct,
        'score': score,
        'max_score': maxScore,
        'understanding': understanding,
        'xp': xp,
        'lesson_completed': lessonCompleted,
      };
}

class AiTutorResponse {
  final String response;
  final List<TutorChoice> choices;
  final LessonState lesson;
  final ProgressUpdate progress;
  final String memorySummary;
  final String flow;
  final String action;
  final Map<String, dynamic> raw;
  final bool wasTruncated;

  const AiTutorResponse({
    required this.response,
    this.choices = const [],
    this.lesson = const LessonState(),
    this.progress = const ProgressUpdate(),
    this.memorySummary = '',
    this.flow = '',
    this.action = 'none',
    this.raw = const {},
    this.wasTruncated = false,
  });

  bool get awaitingAnswer => lesson.awaitingAnswer;
  bool get lessonCompleted => lesson.completed || progress.lessonCompleted;

  factory AiTutorResponse.local({
    required String response,
    List<TutorChoice> choices = const [],
    LessonState lesson = const LessonState(),
    String flow = '',
    String action = 'none',
  }) {
    return AiTutorResponse(
      response: normalizeTutorMarkdown(response),
      choices: choices,
      lesson: lesson,
      flow: flow,
      action: action,
    );
  }

  factory AiTutorResponse.fromJsonMap(
    Map<String, dynamic> map, {
    bool wasTruncated = false,
  }) {
    final rawChoices = map['choices'] ?? map['choice'] ?? const [];
    final choices = <TutorChoice>[];
    if (rawChoices is List) {
      for (var i = 0; i < rawChoices.length; i++) {
        final choice = TutorChoice.fromDynamic(rawChoices[i], i);
        if (choice.label.trim().isNotEmpty) choices.add(choice);
      }
    } else if (rawChoices != null) {
      final choice = TutorChoice.fromDynamic(rawChoices, 0);
      if (choice.label.trim().isNotEmpty) choices.add(choice);
    }

    final memory = map['memory'];
    final memorySummary = memory is Map
        ? _cleanInline(memory['summary'])
        : _cleanInline(map['memory_summary'] ?? memory);

    final ui = map['ui'];
    final uiFlow = ui is Map ? _cleanInline(ui['flow']) : '';
    final action = _normalizeAction(
      map['action'] ?? map['next_action'] ?? map['state'],
    );

    return AiTutorResponse(
      response: normalizeTutorMarkdown(
        map['response'] ?? map['message'] ?? map['answer'] ?? map['text'],
      ),
      choices: choices.take(4).toList(growable: false),
      lesson: LessonState.fromDynamic(map['lesson']),
      progress: ProgressUpdate.fromDynamic(
        map['progress'] ?? map['assessment'] ?? map['evaluation'],
      ),
      memorySummary: memorySummary,
      flow: _cleanInline(map['flow']).isEmpty
          ? uiFlow
          : _cleanInline(map['flow']),
      action: action,
      raw: Map<String, dynamic>.from(map),
      wasTruncated: wasTruncated,
    );
  }

  static AiTutorResponse parse(String rawText) {
    final cleaned = rawText
        .trim()
        .replaceAll(RegExp(r'^```(?:json)?\s*', caseSensitive: false), '')
        .replaceAll(RegExp(r'\s*```$'), '')
        .trim();

    if (cleaned.isEmpty) {
      return const AiTutorResponse(
        response: 'La réponse n’est pas arrivée. Réessaie cette étape.',
        choices: [
          TutorChoice(
            id: 'retry_empty',
            label: 'Réessayer',
            message: 'Reprends exactement la même étape, très brièvement.',
          ),
        ],
        wasTruncated: true,
      );
    }

    final candidate = _extractJsonObject(cleaned);
    if (candidate != null) {
      final decoded = _decodeLenient(candidate);
      final repairedOrIncomplete =
          decoded.$2 || !candidate.trimRight().endsWith('}');
      if (!repairedOrIncomplete && decoded.$1 is Map) {
        final parsed = AiTutorResponse.fromJsonMap(
          Map<String, dynamic>.from(decoded.$1 as Map),
        );
        if (parsed.response.isNotEmpty || parsed.choices.isNotEmpty) {
          return parsed;
        }
      }

      // Ne jamais afficher un texte réparé artificiellement : une chaîne JSON
      // refermée localement peut contenir une phrase réellement coupée.
      if (repairedOrIncomplete) {
        return const AiTutorResponse(
          response:
              'La réponse a été interrompue. Reprenons cette étape proprement.',
          choices: [
            TutorChoice(
              id: 'retry_truncated',
              label: 'Reprendre',
              message:
                  'Reprends exactement cette étape avec une réponse courte et complète.',
            ),
          ],
          wasTruncated: true,
        );
      }
    }

    if (cleaned.startsWith('{') || cleaned.contains('"response"')) {
      // Une sortie JSON coupée ne doit jamais afficher une phrase inachevée.
      // Le service effectuera un essai compact unique; si celui-ci échoue,
      // cette réponse locale, complète, sera affichée.
      return const AiTutorResponse(
        response: 'La réponse a été interrompue. Reprenons cette étape proprement.',
        choices: const [
          TutorChoice(
            id: 'retry_truncated',
            label: 'Reprendre',
            message: 'Reprends exactement cette étape avec une réponse courte.',
          ),
        ],
        wasTruncated: true,
      );
    }

    return AiTutorResponse(response: normalizeTutorMarkdown(cleaned));
  }

  AiTutorResponse normalized({
    required LessonState fallbackLesson,
    required bool lessonMode,
  }) {
    var completeText = normalizeTutorMarkdown(response);
    if (completeText.isEmpty) {
      completeText = lessonMode
          ? 'Continuons cette étape de la leçon.'
          : 'Je suis prêt à t’aider.';
    }

    var normalizedLesson = lesson;
    if (lessonMode) {
      normalizedLesson = lesson.copyWith(
        courseId: lesson.courseId.isEmpty
            ? fallbackLesson.courseId
            : lesson.courseId,
        subject: lesson.subject.isEmpty
            ? fallbackLesson.subject
            : lesson.subject,
        topic: lesson.topic.isEmpty ? fallbackLesson.topic : lesson.topic,
        activity: lesson.activity.isEmpty
            ? fallbackLesson.activity
            : lesson.activity,
        stage: lesson.stage.isEmpty ? fallbackLesson.stage : lesson.stage,
        step: lesson.step <= 0 ? fallbackLesson.step : lesson.step,
        totalSteps: 3,
        completed: lesson.completed,
      );
    }

    var normalizedChoices = choices
        .where((choice) => choice.label.trim().isNotEmpty)
        .take(4)
        .toList(growable: false);
    final normalizedAction = _normalizeAction(action);
    final shouldWait = normalizedAction == 'wait_answer' ||
        (normalizedChoices.isNotEmpty && normalizedAction != 'finish') ||
        (lessonMode &&
            normalizedAction != 'finish' &&
            completeText.contains('?'));

    if (lessonMode) {
      normalizedLesson = normalizedLesson.copyWith(
        awaitingAnswer: shouldWait,
      );
    }

    if (lessonMode && shouldWait && normalizedChoices.isEmpty) {
      normalizedChoices = const [
        TutorChoice(
          id: 'understood',
          label: 'J’ai compris',
          message: 'J’ai compris. Continue avec une petite question.',
        ),
        TutorChoice(
          id: 'example',
          label: 'Un autre exemple',
          message: 'Explique encore avec un autre exemple simple.',
        ),
        TutorChoice(
          id: 'dont_know',
          label: 'Je ne sais pas',
          message: 'Je ne sais pas. Guide-moi étape par étape.',
        ),
      ];
    }

    return AiTutorResponse(
      response: completeText,
      choices: normalizedChoices,
      lesson: normalizedLesson,
      progress: progress,
      memorySummary: _cleanInline(memorySummary),
      flow: flow,
      action: normalizedAction,
      raw: raw,
      wasTruncated: wasTruncated,
    );
  }

  AiTutorResponse copyWith({
    String? response,
    List<TutorChoice>? choices,
    LessonState? lesson,
    ProgressUpdate? progress,
    String? memorySummary,
    String? flow,
    String? action,
    Map<String, dynamic>? raw,
    bool? wasTruncated,
  }) {
    return AiTutorResponse(
      response: response ?? this.response,
      choices: choices ?? this.choices,
      lesson: lesson ?? this.lesson,
      progress: progress ?? this.progress,
      memorySummary: memorySummary ?? this.memorySummary,
      flow: flow ?? this.flow,
      action: action ?? this.action,
      raw: raw ?? this.raw,
      wasTruncated: wasTruncated ?? this.wasTruncated,
    );
  }

  Map<String, dynamic> toJson() => {
        'response': response,
        'choices': choices.map((choice) => choice.toJson()).toList(),
        'action': action,
        'lesson': lesson.toJson(),
        'progress': progress.toJson(),
        'memory_summary': memorySummary,
        if (flow.isNotEmpty) 'flow': flow,
      };

  String toCompactJson() => jsonEncode(toJson());
}

String normalizeTutorMarkdown(dynamic value) {
  var text = value == null ? '' : '$value';
  text = text
      .replaceAll('\r\n', '\n')
      .replaceAll('\r', '\n')
      .replaceAll(r'\n', '\n')
      .replaceAll(r'\t', '  ')
      .replaceAll(RegExp(r'[ \t]+\n'), '\n')
      .replaceAll(RegExp(r'\n{3,}'), '\n\n')
      .trim();

  while (text.endsWith('\\')) {
    text = text.substring(0, text.length - 1).trimRight();
  }

  text = _removeDanglingMarker(text, '**');
  text = _removeDanglingMarker(text, '__');
  text = _removeDanglingMarker(text, '`');

  return text;
}

String _removeDanglingMarker(String text, String marker) {
  if (marker.isEmpty) return text;
  var count = 0;
  var index = 0;
  while (true) {
    index = text.indexOf(marker, index);
    if (index < 0) break;
    count++;
    index += marker.length;
  }
  if (count.isEven) return text;
  final last = text.lastIndexOf(marker);
  return last < 0
      ? text
      : '${text.substring(0, last)}${text.substring(last + marker.length)}';
}

String? _extractJsonObject(String text) {
  final start = text.indexOf('{');
  if (start < 0) return null;
  final end = text.lastIndexOf('}');
  if (end > start) return text.substring(start, end + 1);
  return text.substring(start);
}

(dynamic, bool) _decodeLenient(String candidate) {
  try {
    return (jsonDecode(candidate), false);
  } catch (_) {
    var repaired = candidate.trimRight();
    if (_isInsideString(repaired)) repaired += '"';
    final balance = _jsonBalance(repaired);
    repaired += List<String>.filled(balance.$2, ']').join();
    repaired += List<String>.filled(balance.$1, '}').join();
    try {
      return (jsonDecode(repaired), true);
    } catch (_) {
      return (null, true);
    }
  }
}

(int, int) _jsonBalance(String text) {
  var braces = 0;
  var brackets = 0;
  var inString = false;
  var escaped = false;
  for (final rune in text.runes) {
    final char = String.fromCharCode(rune);
    if (escaped) {
      escaped = false;
      continue;
    }
    if (char == '\\' && inString) {
      escaped = true;
      continue;
    }
    if (char == '"') {
      inString = !inString;
      continue;
    }
    if (inString) continue;
    if (char == '{') braces++;
    if (char == '}') braces--;
    if (char == '[') brackets++;
    if (char == ']') brackets--;
  }
  return (
    braces.clamp(0, 20).toInt(),
    brackets.clamp(0, 20).toInt(),
  );
}

bool _isInsideString(String text) {
  var inString = false;
  var escaped = false;
  for (final rune in text.runes) {
    final char = String.fromCharCode(rune);
    if (escaped) {
      escaped = false;
      continue;
    }
    if (char == '\\' && inString) {
      escaped = true;
      continue;
    }
    if (char == '"') inString = !inString;
  }
  return inString;
}

String _extractJsonStringField(String text, String field) {
  final marker = '"$field"';
  final index = text.indexOf(marker);
  if (index < 0) return '';
  final colon = text.indexOf(':', index + marker.length);
  if (colon < 0) return '';
  final quote = text.indexOf('"', colon + 1);
  if (quote < 0) return '';

  final buffer = StringBuffer();
  var escaped = false;
  for (var i = quote + 1; i < text.length; i++) {
    final char = text[i];
    if (escaped) {
      switch (char) {
        case 'n':
          buffer.write('\n');
          break;
        case 't':
          buffer.write('  ');
          break;
        case 'r':
          break;
        default:
          buffer.write(char);
      }
      escaped = false;
      continue;
    }
    if (char == '\\') {
      escaped = true;
      continue;
    }
    if (char == '"') break;
    buffer.write(char);
  }
  return buffer.toString().trim();
}

String _cleanInline(dynamic value) {
  if (value == null) return '';
  return '$value'
      .replaceAll(r'\n', ' ')
      .replaceAll(r'\t', ' ')
      .replaceAll(RegExp(r'\s+'), ' ')
      .trim();
}

String _normalizeAction(dynamic value) {
  final text = _cleanInline(value).toLowerCase().replaceAll('-', '_');
  switch (text) {
    case 'wait':
    case 'question':
    case 'await_answer':
    case 'wait_answer':
      return 'wait_answer';
    case 'next':
    case 'continue':
    case 'next_step':
      return 'next_step';
    case 'complete':
    case 'completed':
    case 'finish':
      return 'finish';
    default:
      return 'none';
  }
}

int _asInt(dynamic value, {int fallback = 0}) {
  if (value is int) return value;
  if (value is double) return value.round();
  return int.tryParse(_cleanInline(value)) ?? fallback;
}

bool _asBool(dynamic value) {
  if (value is bool) return value;
  final text = _cleanInline(value).toLowerCase();
  return text == 'true' || text == '1' || text == 'yes' || text == 'oui';
}

bool? _asNullableBool(dynamic value) {
  if (value == null) return null;
  return _asBool(value);
}
